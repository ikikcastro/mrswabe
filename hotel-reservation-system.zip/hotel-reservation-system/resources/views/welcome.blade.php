<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>ikik House | Welcome</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body>
    @auth
    <main class="account-page">
        <section class="signed-in-panel">
            <p class="eyebrow">ikik House</p>
            <h1>Your stay starts here.</h1>
            <p class="panel-copy">You are signed in and ready to plan your next escape.</p>
            <form class="logout-form" action="/logout" method="POST">
                @csrf
                <button class="button button-dark" type="submit">Logout</button>
            </form>
        </section>
    </main>
    @else
    <main class="welcome-page">

        <!-- ===== Welcome splash: wordless house-build animation ===== -->
        <section class="welcome-splash" id="welcomeSplash" aria-label="Welcome animation, tap to continue">
            <svg class="house-build" id="houseBuild" viewBox="0 0 400 320" xmlns="http://www.w3.org/2000/svg" role="img" aria-hidden="true">
                <ellipse class="house-ground" cx="200" cy="284" rx="130" ry="8"></ellipse>

                <g class="house-piece piece-wall">
                    <rect x="120" y="180" width="160" height="100" rx="2"></rect>
                </g>

                <g class="house-piece piece-window-left">
                    <rect x="140" y="196" width="26" height="26" rx="1"></rect>
                    <line x1="153" y1="196" x2="153" y2="222"></line>
                    <line x1="140" y1="209" x2="166" y2="209"></line>
                </g>

                <g class="house-piece piece-window-right">
                    <rect x="234" y="196" width="26" height="26" rx="1"></rect>
                    <line x1="247" y1="196" x2="247" y2="222"></line>
                    <line x1="234" y1="209" x2="260" y2="209"></line>
                </g>

                <g class="house-piece piece-door">
                    <rect x="182" y="222" width="36" height="58" rx="1"></rect>
                    <circle class="door-knob" cx="211" cy="252" r="1.6"></circle>
                </g>

                <g class="house-piece piece-roof">
                    <polygon points="108,180 200,104 292,180"></polygon>
                </g>

                <g class="house-piece piece-chimney">
                    <rect x="246" y="120" width="18" height="42"></rect>
                </g>
            </svg>
        </section>

        <!-- ===== Main welcome content (revealed after splash) ===== -->
        <div class="welcome-main" id="welcomeMain">
            <section class="welcome-intro">
                <div class="brand-mark" aria-hidden="true">HH</div>
                <p class="eyebrow">A quieter kind of stay</p>
                <h1>Make room for the good days.</h1>
                <p class="intro-copy">Join ikik House for thoughtful rooms, unhurried mornings, and a place that feels like yours.</p>
                <div class="intro-detail"><span class="detail-line"></span><span>Stay beautifully</span></div>
            </section>

            <section class="auth-area" aria-label="Account access">
                <div class="auth-heading">
                    <p class="eyebrow">Welcome in</p>
                    <h2>Your next chapter is waiting.</h2>
                </div>

                <div class="auth-switch" id="authSwitch" data-active="register">
                    <div class="auth-switch-indicator"></div>
                    <button type="button" id="switchRegister" class="active">Register</button>
                    <button type="button" id="switchLogin">Login</button>
                </div>

                <div class="auth-grid" id="authGrid" data-active="register">
                    <div class="auth-card register-card">
                        <span class="card-number">01</span>
                        <h3>Create an account</h3>
                        <p class="card-copy">Save your details and make every booking feel effortless.</p>
                        <form class="auth-form" action="/register" method="POST">
                            @csrf
                            <label for="register-name">Full name</label>
                            <input id="register-name" name="name" type="text" placeholder="Your name" autocomplete="name" required>
                            <label for="register-email">Email address</label>
                            <input id="register-email" name="email" type="email" placeholder="you@example.com" autocomplete="email" required>
                            <label for="register-password">Password</label>
                            <input id="register-password" name="password" type="password" placeholder="Create a password" autocomplete="new-password" required>
                            <button class="button button-light" type="submit">Register <span aria-hidden="true">&#8594;</span></button>
                        </form>
                        <button type="button" class="auth-swap-link" data-swap="login">Already registered? Log in instead</button>
                    </div>

                    <div class="auth-card login-card">
                        <span class="card-number">02</span>
                        <h3>Welcome back</h3>
                        <p class="card-copy">Already have a room here? Pick up right where you left off.</p>
                        <form class="auth-form" action="/login" method="POST">
                            @csrf
                            <label for="login-name">Name</label>
                            <input id="login-name" name="loginname" type="text" placeholder="Your name" autocomplete="username" required>
                            <label for="login-password">Password</label>
                            <input id="login-password" name="loginpassword" type="password" placeholder="Your password" autocomplete="current-password" required>
                            <button class="button button-dark" type="submit">Login <span aria-hidden="true">&#8594;</span></button>
                        </form>
                        <button type="button" class="auth-swap-link" data-swap="register">New here? Create an account</button>
                    </div>
                </div>
            </section>
        </div>
    </main>
    @endauth

    <script>
        (function () {
            // ----- Register / Login toggle -----
            const switchEl = document.getElementById('authSwitch');
            const gridEl = document.getElementById('authGrid');
            const btnRegister = document.getElementById('switchRegister');
            const btnLogin = document.getElementById('switchLogin');
            const swapLinks = document.querySelectorAll('[data-swap]');

            function setActive(mode) {
                if (!switchEl || !gridEl) return;
                switchEl.dataset.active = mode;
                gridEl.dataset.active = mode;
                btnRegister?.classList.toggle('active', mode === 'register');
                btnLogin?.classList.toggle('active', mode === 'login');
            }

            btnRegister?.addEventListener('click', () => setActive('register'));
            btnLogin?.addEventListener('click', () => setActive('login'));
            swapLinks.forEach(link => {
                link.addEventListener('click', () => setActive(link.dataset.swap));
            });
        })();

        (function () {
            // ----- Wordless house-build splash -----
            const splash = document.getElementById('welcomeSplash');
            const main = document.getElementById('welcomeMain');
            if (!splash || !main) return;

            let done = false;
            let autoTimer;

            function reveal() {
                if (done) return;
                done = true;
                clearTimeout(autoTimer);
                splash.classList.add('is-leaving');
                setTimeout(() => {
                    splash.style.display = 'none';
                    main.classList.add('is-entering');
                }, 500);
            }

            // Auto-advance once the house has fully assembled and settled.
            autoTimer = setTimeout(reveal, 3400);

            // Let impatient users tap/click anywhere to skip straight through.
            splash.addEventListener('click', reveal);
        })();
    </script>
</body>
</html>
