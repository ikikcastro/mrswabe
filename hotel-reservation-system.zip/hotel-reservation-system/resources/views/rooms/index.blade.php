<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>ikik House | Rooms</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="rooms-body">

    @php
        // Demo data — replace with $rooms passed from your RoomController.
        // Expected shape per room: id, name, tier (signature|comfort|essential),
        // price, blurb, image, tags[]
        $rooms = $rooms ?? [
            [
                'id' => 1, 'tier' => 'signature', 'name' => 'The Moss Suite',
                'price' => '6,800', 'blurb' => 'Corner suite with a soaking tub and skyline views.',
                'image' => 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1600&q=70',
                'tags' => ['King bed', 'Soaking tub', 'Skyline view'],
            ],
            [
                'id' => 2, 'tier' => 'comfort', 'name' => 'Garden Room',
                'price' => '3,400', 'blurb' => 'Warm, quiet, and just the right size for two.',
                'image' => 'https://images.unsplash.com/photo-1611892440504-42a792e24d32?auto=format&fit=crop&w=1600&q=70',
                'tags' => ['Queen bed', 'Garden view', 'Work desk'],
            ],
            [
                'id' => 3, 'tier' => 'essential', 'name' => 'The Nook',
                'price' => '1,650', 'blurb' => 'A well-kept single room for the traveler who just needs rest.',
                'image' => 'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=1600&q=70',
                'tags' => ['Single bed', 'Fast Wi-Fi', 'Free coffee'],
            ],
            [
                'id' => 4, 'tier' => 'signature', 'name' => 'The Penthouse',
                'price' => '9,200', 'blurb' => 'Top-floor privacy with a private terrace and butler call.',
                'image' => 'https://images.unsplash.com/photo-1591088398332-8a7791972843?auto=format&fit=crop&w=1600&q=70',
                'tags' => ['Private terrace', 'Butler service', 'Rain shower'],
            ],
            [
                'id' => 5, 'tier' => 'comfort', 'name' => 'Courtyard Room',
                'price' => '3,100', 'blurb' => 'Opens onto the inner courtyard — quiet even at noon.',
                'image' => 'https://images.unsplash.com/photo-1618773928121-c32242e63f39?auto=format&fit=crop&w=1600&q=70',
                'tags' => ['Twin beds', 'Courtyard access', 'Reading nook'],
            ],
            [
                'id' => 6, 'tier' => 'essential', 'name' => 'Budget Bunk',
                'price' => '1,200', 'blurb' => 'Simple, clean, and easy on the wallet without cutting comfort.',
                'image' => 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=1600&q=70',
                'tags' => ['Bunk bed', 'Shared lounge', 'Locker'],
            ],
        ];

        $tierLabel = [
            'signature' => 'Signature',
            'comfort'   => 'Comfort',
            'essential' => 'Essential',
        ];
    @endphp

    <!-- ===== Top navigation ===== -->
    <header class="site-nav">
        <a href="{{ url('/') }}" class="nav-brand">
            <span class="brand-mark brand-mark--sm" aria-hidden="true">HH</span>
            <span class="nav-brand-name">ikik House</span>
        </a>

        <nav class="nav-links" aria-label="Primary">
            <a href="{{ url('/rooms') }}" class="nav-link is-active">Rooms</a>
            <a href="{{ url('/bookings') }}" class="nav-link">My bookings</a>
            <a href="{{ url('/amenities') }}" class="nav-link">Amenities</a>
        </nav>

        <div class="nav-user">
            <span class="nav-greeting">Welcome back, {{ Auth::user()->name ?? 'guest' }}</span>
            <form action="/logout" method="POST" class="nav-logout-form">
                @csrf
                <button class="button button-dark button-sm" type="submit">Logout</button>
            </form>
        </div>
    </header>

    <!-- ===== Photo slideshow hero ===== -->
    <section class="room-slideshow" id="roomSlideshow" aria-label="Room photo slideshow">
        @foreach ($rooms as $i => $room)
            <div class="slide {{ $i === 0 ? 'is-active' : '' }}" data-index="{{ $i }}">
                <button type="button" class="slide-image-btn" data-lightbox-src="{{ $room['image'] }}" data-lightbox-alt="{{ $room['name'] }}">
                    <img src="{{ $room['image'] }}" alt="{{ $room['name'] }}" loading="{{ $i === 0 ? 'eager' : 'lazy' }}">
                </button>

                <div class="slide-scrim" aria-hidden="true"></div>

                <div class="slide-overlay">
                    <span class="tier-badge tier-badge--{{ $room['tier'] }}">{{ $tierLabel[$room['tier']] }}</span>
                    <h2>{{ $room['name'] }}</h2>
                    <p>{{ $room['blurb'] }}</p>
                    <button
                        type="button"
                        class="button button-light explore-btn"
                        data-id="{{ $room['id'] }}"
                        data-name="{{ $room['name'] }}"
                        data-tier="{{ $room['tier'] }}"
                        data-price="{{ $room['price'] }}"
                        data-image="{{ $room['image'] }}"
                        data-blurb="{{ $room['blurb'] }}"
                        data-tags="{{ implode('|', $room['tags']) }}"
                    >
                        Explore <span aria-hidden="true">&#8594;</span>
                    </button>
                </div>
            </div>
        @endforeach

        <div class="slideshow-dots" id="slideshowDots">
            @foreach ($rooms as $i => $room)
                <button type="button" class="slideshow-dot {{ $i === 0 ? 'is-active' : '' }}" data-goto="{{ $i }}" aria-label="Show {{ $room['name'] }}"></button>
            @endforeach
        </div>

        <p class="slideshow-hint">Tap a photo to view it fullscreen</p>
    </section>

    <!-- ===== Tier filter ===== -->
    <section class="rooms-filter-wrap">
        <p class="eyebrow filter-eyebrow">Browse all rooms</p>
        <div class="rooms-filter" id="roomsFilter" data-active="all">
            <button type="button" class="filter-pill is-active" data-filter="all">All stays</button>
            <button type="button" class="filter-pill" data-filter="signature">Signature suites</button>
            <button type="button" class="filter-pill" data-filter="comfort">Comfort rooms</button>
            <button type="button" class="filter-pill" data-filter="essential">Essentials</button>
        </div>
    </section>

    <!-- ===== Room grid ===== -->
    <section class="rooms-grid" id="roomsGrid">
        @forelse ($rooms as $i => $room)
            <article class="room-card reveal" data-tier="{{ $room['tier'] }}" style="--reveal-delay: {{ ($i % 3) * 0.1 }}s">
                <div class="room-media">
                    <button type="button" class="slide-image-btn" data-lightbox-src="{{ $room['image'] }}" data-lightbox-alt="{{ $room['name'] }}">
                        <img src="{{ $room['image'] }}" alt="{{ $room['name'] }}" loading="lazy">
                    </button>
                    <span class="tier-badge tier-badge--{{ $room['tier'] }}">{{ $tierLabel[$room['tier']] }}</span>
                </div>

                <div class="room-body">
                    <h3>{{ $room['name'] }}</h3>
                    <p class="room-blurb">{{ $room['blurb'] }}</p>

                    <ul class="room-tags">
                        @foreach ($room['tags'] as $tag)
                            <li>{{ $tag }}</li>
                        @endforeach
                    </ul>

                    <div class="room-footer">
                        <div class="room-price">
                            <span class="price-amount">&#8369;{{ $room['price'] }}</span>
                            <span class="price-unit">/ night</span>
                        </div>
                        <button
                            type="button"
                            class="button button-light room-cta explore-btn"
                            data-id="{{ $room['id'] }}"
                            data-name="{{ $room['name'] }}"
                            data-tier="{{ $room['tier'] }}"
                            data-price="{{ $room['price'] }}"
                            data-image="{{ $room['image'] }}"
                            data-blurb="{{ $room['blurb'] }}"
                            data-tags="{{ implode('|', $room['tags']) }}"
                        >
                            Explore <span aria-hidden="true">&#8594;</span>
                        </button>
                    </div>
                </div>
            </article>
        @empty
            <p class="rooms-empty">No rooms are available right now — check back soon.</p>
        @endforelse
    </section>

    <!-- ===== Fullscreen image lightbox ===== -->
    <div class="lightbox" id="lightbox" aria-hidden="true">
        <button type="button" class="lightbox-close" id="lightboxClose" aria-label="Close fullscreen image">&#10005;</button>
        <img src="" alt="" id="lightboxImage">
    </div>

    <!-- ===== Explore detail modal ===== -->
    <div class="explore-modal" id="exploreModal" aria-hidden="true">
        <div class="explore-modal-backdrop" id="exploreModalBackdrop"></div>
        <div class="explore-modal-panel" role="dialog" aria-modal="true" aria-labelledby="exploreModalTitle">
            <button type="button" class="explore-modal-close" id="exploreModalClose" aria-label="Close room details">&#10005;</button>

            <div class="explore-modal-media">
                <img src="" alt="" id="exploreModalImage">
                <span class="tier-badge" id="exploreModalTier"></span>
            </div>

            <div class="explore-modal-body">
                <h3 id="exploreModalTitle"></h3>
                <p class="explore-modal-blurb" id="exploreModalBlurb"></p>

                <div class="explore-modal-price">
                    <span class="price-amount" id="exploreModalPrice"></span>
                    <span class="price-unit">/ night</span>
                </div>

                <p class="explore-modal-label">What's included</p>
                <ul class="explore-modal-tags" id="exploreModalTags"></ul>

                <button type="button" class="button button-dark" id="exploreModalBook">Book this room</button>
            </div>
        </div>
    </div>

    <!-- ===== Booking form modal ===== -->
    <div class="booking-modal" id="bookingModal" aria-hidden="true">
        <div class="explore-modal-backdrop" id="bookingModalBackdrop"></div>
        <div class="booking-modal-panel" role="dialog" aria-modal="true" aria-labelledby="bookingModalTitle">
            <button type="button" class="explore-modal-close" id="bookingModalClose" aria-label="Close booking form">&#10005;</button>

            <!-- ----- Form step ----- -->
            <div class="booking-step is-active" id="bookingFormStep">
                <p class="eyebrow" id="bookingModalRoomName"></p>
                <h3 id="bookingModalTitle">Request this room</h3>
                <p class="intro-copy admin-modal-copy">Send your details and our team will confirm availability.</p>

                <form class="auth-form booking-form" id="bookingForm">
                    <label for="bookingFullname">Full name</label>
                    <input id="bookingFullname" type="text" placeholder="Your full name" required>

                    <label for="bookingStayDates">Stay dates</label>
                    <div class="payment-fields-row">
                        <div>
                            <input id="bookingCheckin" type="date" required>
                        </div>
                        <div>
                            <input id="bookingCheckout" type="date" required>
                        </div>
                    </div>

                    <label for="bookingContact">Contact number</label>
                    <input id="bookingContact" type="tel" placeholder="09XX XXX XXXX" required>

                    <button type="submit" class="button button-dark booking-submit">Submit booking request <span aria-hidden="true">&#8594;</span></button>
                </form>
            </div>

            <!-- ----- Sending animation step ----- -->
            <div class="booking-step" id="bookingSendStep">
                <div class="envelope-scene" aria-hidden="true">
                    <div class="envelope-box">
                        <div class="box-flap-back"></div>
                        <div class="envelope" id="envelopeEl">
                            <div class="envelope-back"></div>
                            <div class="envelope-flap"></div>
                            <div class="envelope-front"></div>
                        </div>
                        <div class="box-flap-front"></div>
                    </div>
                </div>
                <p class="booking-sending-text" id="bookingSendingText">Sending your booking request&hellip;</p>
            </div>

            <!-- ----- Confirmation step ----- -->
            <div class="booking-step" id="bookingDoneStep">
                <div class="booking-done-check" aria-hidden="true">
                    <svg viewBox="0 0 52 52"><circle cx="26" cy="26" r="24"></circle><path d="M15 27l7 7 15-15"></path></svg>
                </div>
                <h3>Request sent</h3>
                <p class="intro-copy admin-modal-copy" id="bookingDoneCopy">We've received your booking request. Our team will confirm availability and follow up shortly.</p>
                <button type="button" class="button button-light" id="bookingDoneClose">Done</button>
            </div>
        </div>
    </div>

    <script>
        (function () {
            // ----- Photo slideshow (autoplay crossfade + dots) -----
            const slideshow = document.getElementById('roomSlideshow');
            if (slideshow) {
                const slides = slideshow.querySelectorAll('.slide');
                const dots = document.querySelectorAll('.slideshow-dot');
                let current = 0;
                let autoplay;

                function goTo(index) {
                    slides[current]?.classList.remove('is-active');
                    dots[current]?.classList.remove('is-active');
                    current = index;
                    slides[current]?.classList.add('is-active');
                    dots[current]?.classList.add('is-active');
                }

                function next() {
                    goTo((current + 1) % slides.length);
                }

                function startAutoplay() {
                    clearInterval(autoplay);
                    autoplay = setInterval(next, 4500);
                }

                dots.forEach(dot => {
                    dot.addEventListener('click', () => {
                        goTo(Number(dot.dataset.goto));
                        startAutoplay();
                    });
                });

                if (slides.length > 1) startAutoplay();
            }

            // ----- Fullscreen lightbox -----
            const lightbox = document.getElementById('lightbox');
            const lightboxImage = document.getElementById('lightboxImage');
            const lightboxClose = document.getElementById('lightboxClose');

            function openLightbox(src, alt) {
                lightboxImage.src = src;
                lightboxImage.alt = alt || '';
                lightbox.classList.add('is-open');
                lightbox.setAttribute('aria-hidden', 'false');
                document.body.classList.add('no-scroll');
            }

            function closeLightbox() {
                lightbox.classList.remove('is-open');
                lightbox.setAttribute('aria-hidden', 'true');
                document.body.classList.remove('no-scroll');
            }

            document.querySelectorAll('.slide-image-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    openLightbox(btn.dataset.lightboxSrc, btn.dataset.lightboxAlt);
                });
            });

            lightboxClose?.addEventListener('click', closeLightbox);
            lightbox?.addEventListener('click', (e) => {
                if (e.target === lightbox) closeLightbox();
            });

            // ----- Explore detail modal -----
            const modal = document.getElementById('exploreModal');
            const modalBackdrop = document.getElementById('exploreModalBackdrop');
            const modalClose = document.getElementById('exploreModalClose');
            const modalImage = document.getElementById('exploreModalImage');
            const modalTier = document.getElementById('exploreModalTier');
            const modalTitle = document.getElementById('exploreModalTitle');
            const modalBlurb = document.getElementById('exploreModalBlurb');
            const modalPrice = document.getElementById('exploreModalPrice');
            const modalTags = document.getElementById('exploreModalTags');
            const modalBook = document.getElementById('exploreModalBook');

            const tierLabels = { signature: 'Signature', comfort: 'Comfort', essential: 'Essential' };
            let currentBookingRoom = null;

            function openExploreModal(data) {
                modalImage.src = data.image;
                modalImage.alt = data.name;
                modalTier.textContent = tierLabels[data.tier] || data.tier;
                modalTier.className = 'tier-badge tier-badge--' + data.tier;
                modalTitle.textContent = data.name;
                modalBlurb.textContent = data.blurb;
                modalPrice.textContent = '\u20B1' + data.price;
                modalTags.innerHTML = '';
                data.tags.split('|').forEach(tag => {
                    if (!tag) return;
                    const li = document.createElement('li');
                    li.textContent = tag;
                    modalTags.appendChild(li);
                });
                currentBookingRoom = data;

                modal.classList.add('is-open');
                modal.setAttribute('aria-hidden', 'false');
                document.body.classList.add('no-scroll');
            }

            function closeExploreModal() {
                modal.classList.remove('is-open');
                modal.setAttribute('aria-hidden', 'true');
                document.body.classList.remove('no-scroll');
            }

            modalBook?.addEventListener('click', () => {
                closeExploreModal();
                openBookingModal(currentBookingRoom);
            });

            document.querySelectorAll('.explore-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    openExploreModal(btn.dataset);
                });
            });

            modalClose?.addEventListener('click', closeExploreModal);
            modalBackdrop?.addEventListener('click', closeExploreModal);

            // ----- Booking form modal (form -> envelope animation -> confirmation) -----
            const bookingModal = document.getElementById('bookingModal');
            const bookingModalBackdrop = document.getElementById('bookingModalBackdrop');
            const bookingModalClose = document.getElementById('bookingModalClose');
            const bookingModalRoomName = document.getElementById('bookingModalRoomName');
            const bookingForm = document.getElementById('bookingForm');
            const bookingFormStep = document.getElementById('bookingFormStep');
            const bookingSendStep = document.getElementById('bookingSendStep');
            const bookingDoneStep = document.getElementById('bookingDoneStep');
            const bookingDoneCopy = document.getElementById('bookingDoneCopy');
            const bookingDoneClose = document.getElementById('bookingDoneClose');
            const bookingDoneClose = document.getElementById('bookingDoneClose');

            function showBookingStep(step) {
                [bookingFormStep, bookingSendStep, bookingDoneStep].forEach(el => {
                    el.classList.toggle('is-active', el === step);
                });
            }

            function openBookingModal(room) {
                if (!room) return;
                bookingModalRoomName.textContent = room.name || '';
                bookingForm.reset();
                showBookingStep(bookingFormStep);
                bookingModal.classList.add('is-open');
                bookingModal.setAttribute('aria-hidden', 'false');
                document.body.classList.add('no-scroll');
            }

            function closeBookingModal() {
                bookingModal.classList.remove('is-open');
                bookingModal.setAttribute('aria-hidden', 'true');
                document.body.classList.remove('no-scroll');
            }

            bookingModalClose?.addEventListener('click', closeBookingModal);
            bookingModalBackdrop?.addEventListener('click', closeBookingModal);
            bookingDoneClose?.addEventListener('click', closeBookingModal);

            bookingForm?.addEventListener('submit', (e) => {
                e.preventDefault();
                // NOTE: demo only — wire this to a real POST to your BookingController.
                const name = document.getElementById('bookingFullname').value || 'your';
                showBookingStep(bookingSendStep);

                const envelope = document.getElementById('envelopeEl');
                const sendingText = document.getElementById('bookingSendingText');
                envelope.classList.remove('is-sealed', 'is-dropping');
                // restart animation on repeat submissions
                void envelope.offsetWidth;

                // Full sequence runs 10s, with the status line updating in step
                // with the envelope so the wait reads as progress, not a stall.
                sendingText.textContent = 'Sealing your request\u2026';
                requestAnimationFrame(() => envelope.classList.add('is-sealed'));

                setTimeout(() => {
                    sendingText.textContent = 'Sending it to our front desk\u2026';
                    envelope.classList.add('is-dropping');
                }, 3500);

                setTimeout(() => {
                    sendingText.textContent = 'Almost there\u2026';
                }, 7500);

                setTimeout(() => {
                    bookingDoneCopy.textContent = `Thanks, ${name}! We've received your booking request and will confirm availability shortly.`;
                    showBookingStep(bookingDoneStep);
                }, 10000);
            });

            document.addEventListener('keydown', (e) => {
                if (e.key !== 'Escape') return;
                if (lightbox?.classList.contains('is-open')) closeLightbox();
                if (modal?.classList.contains('is-open')) closeExploreModal();
                if (bookingModal?.classList.contains('is-open')) closeBookingModal();
            });

            // ----- Tier filter with fade/scale transition -----
            const filterWrap = document.getElementById('roomsFilter');
            const grid = document.getElementById('roomsGrid');
            if (filterWrap && grid) {
                const pills = filterWrap.querySelectorAll('.filter-pill');
                const cards = grid.querySelectorAll('.room-card');

                function applyFilter(tier) {
                    filterWrap.dataset.active = tier;
                    pills.forEach(p => p.classList.toggle('is-active', p.dataset.filter === tier));

                    cards.forEach(card => {
                        const matches = tier === 'all' || card.dataset.tier === tier;
                        if (matches) {
                            card.classList.remove('is-filtered-out');
                            card.style.display = '';
                            requestAnimationFrame(() => card.classList.remove('is-hiding'));
                        } else {
                            card.classList.add('is-hiding');
                            setTimeout(() => {
                                if (card.classList.contains('is-hiding')) card.style.display = 'none';
                            }, 280);
                        }
                    });
                }

                pills.forEach(pill => {
                    pill.addEventListener('click', () => applyFilter(pill.dataset.filter));
                });
            }

            // ----- Scroll-reveal for room cards -----
            const revealEls = document.querySelectorAll('.reveal');
            const io = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('is-visible');
                        io.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.15 });

            revealEls.forEach(el => io.observe(el));
        })();
    </script>
</body>
</html>
