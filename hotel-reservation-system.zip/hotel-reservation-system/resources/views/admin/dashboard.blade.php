<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ikik House | Owner Dashboard</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="admin-body">

    @php
        // Demo data — replace with real data from your controllers.
        $stats = $stats ?? [
            'checkins_today' => 4,
            'occupancy' => 72,
            'pending' => 3,
            'revenue_month' => '184,300',
        ];

        $rooms = $rooms ?? [
            ['id' => 1, 'name' => 'The Moss Suite', 'tier' => 'signature', 'price' => '6,800', 'status' => 'available'],
            ['id' => 2, 'name' => 'Garden Room', 'tier' => 'comfort', 'price' => '3,400', 'status' => 'available'],
            ['id' => 3, 'name' => 'The Nook', 'tier' => 'essential', 'price' => '1,650', 'status' => 'maintenance'],
            ['id' => 4, 'name' => 'The Penthouse', 'tier' => 'signature', 'price' => '9,200', 'status' => 'available'],
        ];

        $reservations = $reservations ?? [
            ['id' => 101, 'guest' => 'Ana Reyes', 'room' => 'The Moss Suite', 'checkin' => 'Aug 22', 'checkout' => 'Aug 24', 'status' => 'pending', 'conflict' => false],
            ['id' => 102, 'guest' => 'Liam Cruz', 'room' => 'Garden Room', 'checkin' => 'Aug 21', 'checkout' => 'Aug 23', 'status' => 'confirmed', 'conflict' => false],
            ['id' => 103, 'guest' => 'Mika Santos', 'room' => 'The Moss Suite', 'checkin' => 'Aug 23', 'checkout' => 'Aug 25', 'status' => 'pending', 'conflict' => true],
            ['id' => 104, 'guest' => 'Ben Torres', 'room' => 'The Nook', 'checkin' => 'Aug 20', 'checkout' => 'Aug 21', 'status' => 'checked_out', 'conflict' => false],
            ['id' => 105, 'guest' => 'Grace Lim', 'room' => 'The Penthouse', 'checkin' => 'Aug 26', 'checkout' => 'Aug 29', 'status' => 'cancelled', 'conflict' => false],
        ];

        $weekBookings = $weekBookings ?? [4, 7, 5, 9, 6, 11, 8]; // Mon..Sun, for the CSS bar chart

        $statusLabel = [
            'pending' => 'Pending', 'confirmed' => 'Confirmed',
            'checked_in' => 'Checked in', 'checked_out' => 'Checked out', 'cancelled' => 'Cancelled',
        ];
        $tierLabel = ['signature' => 'Signature', 'comfort' => 'Comfort', 'essential' => 'Essential'];
    @endphp

    <div class="admin-shell">
        <!-- ===== Sidebar ===== -->
        <aside class="admin-sidebar" id="adminSidebar">
            <div class="admin-brand">
                <span class="brand-mark brand-mark--sm" aria-hidden="true">HH</span>
                <span class="nav-brand-name">ikik House</span>
            </div>

            <nav class="admin-nav" aria-label="Dashboard sections">
                <button type="button" class="admin-nav-link is-active" data-section="overview">Overview</button>
                <button type="button" class="admin-nav-link" data-section="rooms">Rooms</button>
                <button type="button" class="admin-nav-link" data-section="reservations">Reservations</button>
                <button type="button" class="admin-nav-link" data-section="reports">Reports</button>
            </nav>

            <form action="/logout" method="POST" class="admin-sidebar-logout">
                @csrf
                <button class="button button-dark button-sm" type="submit">Logout</button>
            </form>
        </aside>

        <div class="admin-scrim" id="adminScrim"></div>

        <!-- ===== Main content ===== -->
        <div class="admin-main">
            <header class="admin-topbar">
                <button type="button" class="admin-menu-toggle" id="adminMenuToggle" aria-label="Toggle menu">
                    <span></span><span></span><span></span>
                </button>
                <p class="admin-topbar-title" id="adminSectionTitle">Overview</p>
                <span class="admin-owner-chip">Signed in as {{ Auth::user()->name ?? 'Mark' }} · Owner</span>
            </header>

            <!-- ===== Overview ===== -->
            <section class="admin-section is-active" id="section-overview">
                <div class="admin-stat-grid">
                    <div class="admin-stat-card reveal">
                        <p class="admin-stat-label">Check-ins today</p>
                        <p class="admin-stat-value" data-count-to="{{ $stats['checkins_today'] }}">0</p>
                    </div>
                    <div class="admin-stat-card reveal" style="--reveal-delay:0.08s">
                        <p class="admin-stat-label">Occupancy rate</p>
                        <p class="admin-stat-value" data-count-to="{{ $stats['occupancy'] }}" data-suffix="%">0</p>
                    </div>
                    <div class="admin-stat-card reveal" style="--reveal-delay:0.16s">
                        <p class="admin-stat-label">Pending reservations</p>
                        <p class="admin-stat-value" data-count-to="{{ $stats['pending'] }}">0</p>
                    </div>
                    <div class="admin-stat-card reveal" style="--reveal-delay:0.24s">
                        <p class="admin-stat-label">Revenue this month</p>
                        <p class="admin-stat-value admin-stat-value--money">&#8369;{{ $stats['revenue_month'] }}</p>
                    </div>
                </div>

                <div class="admin-panel reveal">
                    <div class="admin-panel-heading">
                        <h3>Needs your attention</h3>
                    </div>
                    <ul class="admin-alert-list">
                        @foreach ($reservations as $r)
                            @if ($r['conflict'])
                                <li class="admin-alert admin-alert--danger">
                                    <span>Double-booking risk: <strong>{{ $r['room'] }}</strong> has overlapping dates for {{ $r['guest'] }} ({{ $r['checkin'] }}–{{ $r['checkout'] }}).</span>
                                    <button type="button" class="admin-alert-action" data-goto-section="reservations">Review</button>
                                </li>
                            @endif
                        @endforeach
                        @foreach ($rooms as $room)
                            @if ($room['status'] === 'maintenance')
                                <li class="admin-alert admin-alert--warning">
                                    <span><strong>{{ $room['name'] }}</strong> is marked under maintenance and hidden from customer bookings.</span>
                                    <button type="button" class="admin-alert-action" data-goto-section="rooms">Review</button>
                                </li>
                            @endif
                        @endforeach
                    </ul>
                </div>
            </section>

            <!-- ===== Rooms management ===== -->
            <section class="admin-section" id="section-rooms">
                <div class="admin-panel-heading admin-panel-heading--row">
                    <h3>Room information</h3>
                    <button type="button" class="button button-dark button-sm" id="addRoomBtn">+ Add room</button>
                </div>

                <div class="admin-table-wrap reveal">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Room</th>
                                <th>Tier</th>
                                <th>Price / night</th>
                                <th>Status</th>
                                <th class="admin-table-actions-col">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="roomsTableBody">
                            @foreach ($rooms as $room)
                                <tr data-room-id="{{ $room['id'] }}">
                                    <td>{{ $room['name'] }}</td>
                                    <td><span class="tier-badge tier-badge--{{ $room['tier'] }}">{{ $tierLabel[$room['tier']] }}</span></td>
                                    <td>&#8369;{{ $room['price'] }}</td>
                                    <td>
                                        <span class="status-pill status-pill--{{ $room['status'] === 'available' ? 'good' : 'warn' }}">
                                            {{ $room['status'] === 'available' ? 'Available' : 'Maintenance' }}
                                        </span>
                                    </td>
                                    <td class="admin-table-actions">
                                        <button type="button" class="admin-icon-btn edit-room-btn"
                                            data-id="{{ $room['id'] }}" data-name="{{ $room['name'] }}"
                                            data-tier="{{ $room['tier'] }}" data-price="{{ $room['price'] }}"
                                            data-status="{{ $room['status'] }}">Edit</button>
                                        <button type="button" class="admin-icon-btn admin-icon-btn--danger delete-room-btn"
                                            data-id="{{ $room['id'] }}" data-name="{{ $room['name'] }}">Delete</button>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </section>

            <!-- ===== Reservations ===== -->
            <section class="admin-section" id="section-reservations">
                <div class="admin-panel-heading admin-panel-heading--row">
                    <h3>Reservations</h3>
                    <div class="admin-filter" id="reservationFilter" data-active="all">
                        <button type="button" class="filter-pill is-active" data-filter="all">All</button>
                        <button type="button" class="filter-pill" data-filter="pending">Pending</button>
                        <button type="button" class="filter-pill" data-filter="confirmed">Confirmed</button>
                        <button type="button" class="filter-pill" data-filter="checked_out">Completed</button>
                        <button type="button" class="filter-pill" data-filter="cancelled">Cancelled</button>
                    </div>
                </div>

                <div class="admin-table-wrap reveal">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Guest</th>
                                <th>Room</th>
                                <th>Check-in</th>
                                <th>Check-out</th>
                                <th>Status</th>
                                <th class="admin-table-actions-col">Update status</th>
                            </tr>
                        </thead>
                        <tbody id="reservationsTableBody">
                            @foreach ($reservations as $r)
                                <tr data-reservation-id="{{ $r['id'] }}" data-status="{{ $r['status'] }}" class="{{ $r['conflict'] ? 'is-conflict' : '' }}">
                                    <td>
                                        {{ $r['guest'] }}
                                        @if ($r['conflict'])
                                            <span class="conflict-flag" title="Overlaps with another booking for this room">&#9888; Conflict</span>
                                        @endif
                                    </td>
                                    <td>{{ $r['room'] }}</td>
                                    <td>{{ $r['checkin'] }}</td>
                                    <td>{{ $r['checkout'] }}</td>
                                    <td>
                                        <span class="status-pill status-pill--{{ $r['status'] }}">{{ $statusLabel[$r['status']] }}</span>
                                    </td>
                                    <td>
                                        <select class="status-select" data-reservation-id="{{ $r['id'] }}">
                                            @foreach ($statusLabel as $value => $label)
                                                <option value="{{ $value }}" {{ $r['status'] === $value ? 'selected' : '' }}>{{ $label }}</option>
                                            @endforeach
                                        </select>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </section>

            <!-- ===== Reports ===== -->
            <section class="admin-section" id="section-reports">
                <div class="admin-panel-heading admin-panel-heading--row">
                    <h3>Reports</h3>
                    <button type="button" class="button button-dark button-sm" id="exportReportBtn">Export CSV</button>
                </div>

                <div class="admin-stat-grid admin-stat-grid--3">
                    <div class="admin-stat-card reveal">
                        <p class="admin-stat-label">Bookings this month</p>
                        <p class="admin-stat-value" data-count-to="58">0</p>
                    </div>
                    <div class="admin-stat-card reveal" style="--reveal-delay:0.08s">
                        <p class="admin-stat-label">Revenue this month</p>
                        <p class="admin-stat-value admin-stat-value--money">&#8369;{{ $stats['revenue_month'] }}</p>
                    </div>
                    <div class="admin-stat-card reveal" style="--reveal-delay:0.16s">
                        <p class="admin-stat-label">Average occupancy</p>
                        <p class="admin-stat-value" data-count-to="{{ $stats['occupancy'] }}" data-suffix="%">0</p>
                    </div>
                </div>

                <div class="admin-panel reveal">
                    <div class="admin-panel-heading">
                        <h3>Bookings this week</h3>
                    </div>
                    <div class="admin-bar-chart" id="weekChart">
                        @foreach ($weekBookings as $i => $count)
                            <div class="bar-col">
                                <div class="bar-fill" data-height="{{ $count }}" style="--bar-delay: {{ $i * 0.08 }}s"></div>
                                <span class="bar-label">{{ ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'][$i] }}</span>
                            </div>
                        @endforeach
                    </div>
                </div>
            </section>
        </div>
    </div>

    <!-- ===== Add / Edit Room modal ===== -->
    <div class="admin-modal" id="roomModal" aria-hidden="true">
        <div class="explore-modal-backdrop" id="roomModalBackdrop"></div>
        <div class="admin-modal-panel" role="dialog" aria-modal="true" aria-labelledby="roomModalTitle">
            <button type="button" class="explore-modal-close" id="roomModalClose" aria-label="Close">&#10005;</button>
            <h3 id="roomModalTitle">Add room</h3>

            <form class="auth-form admin-modal-form" id="roomForm">
                <label for="roomName">Room name</label>
                <input id="roomName" type="text" placeholder="e.g. The Moss Suite" required>

                <label for="roomTier">Tier</label>
                <select id="roomTier" required>
                    <option value="signature">Signature</option>
                    <option value="comfort">Comfort</option>
                    <option value="essential">Essential</option>
                </select>

                <label for="roomPrice">Price per night (&#8369;)</label>
                <input id="roomPrice" type="number" min="0" placeholder="e.g. 3400" required>

                <label for="roomStatus">Status</label>
                <select id="roomStatus" required>
                    <option value="available">Available</option>
                    <option value="maintenance">Maintenance</option>
                </select>

                <button class="button button-dark" type="submit">Save room</button>
            </form>
        </div>
    </div>

    <!-- ===== Delete confirm modal ===== -->
    <div class="admin-modal" id="deleteModal" aria-hidden="true">
        <div class="explore-modal-backdrop" id="deleteModalBackdrop"></div>
        <div class="admin-modal-panel admin-modal-panel--sm" role="dialog" aria-modal="true">
            <h3>Remove room?</h3>
            <p class="intro-copy admin-modal-copy" id="deleteModalCopy">This will remove the room from the booking site.</p>
            <div class="admin-modal-actions">
                <button type="button" class="button button-light button-sm" id="deleteModalCancel">Cancel</button>
                <button type="button" class="button button-dark button-sm admin-modal-danger" id="deleteModalConfirm">Delete</button>
            </div>
        </div>
    </div>

    <!-- ===== Toast ===== -->
    <div class="admin-toast" id="adminToast" aria-live="polite"></div>

    <script>
        (function () {
            // ----- Sidebar section switching -----
            const navLinks = document.querySelectorAll('.admin-nav-link');
            const sections = document.querySelectorAll('.admin-section');
            const sectionTitle = document.getElementById('adminSectionTitle');
            const sidebar = document.getElementById('adminSidebar');
            const scrim = document.getElementById('adminScrim');
            const menuToggle = document.getElementById('adminMenuToggle');

            function showSection(name) {
                sections.forEach(s => s.classList.toggle('is-active', s.id === 'section-' + name));
                navLinks.forEach(l => l.classList.toggle('is-active', l.dataset.section === name));
                const activeLink = [...navLinks].find(l => l.dataset.section === name);
                if (activeLink) sectionTitle.textContent = activeLink.textContent;
                sidebar.classList.remove('is-open');
                scrim.classList.remove('is-open');
            }

            navLinks.forEach(link => link.addEventListener('click', () => showSection(link.dataset.section)));
            document.querySelectorAll('[data-goto-section]').forEach(btn => {
                btn.addEventListener('click', () => showSection(btn.dataset.gotoSection));
            });

            menuToggle?.addEventListener('click', () => {
                sidebar.classList.toggle('is-open');
                scrim.classList.toggle('is-open');
            });
            scrim?.addEventListener('click', () => {
                sidebar.classList.remove('is-open');
                scrim.classList.remove('is-open');
            });

            // ----- Count-up stat animation -----
            function animateCount(el) {
                const target = Number(el.dataset.countTo || 0);
                const suffix = el.dataset.suffix || '';
                const duration = 900;
                const start = performance.now();

                function tick(now) {
                    const progress = Math.min((now - start) / duration, 1);
                    const eased = 1 - Math.pow(1 - progress, 3);
                    el.textContent = Math.round(target * eased) + suffix;
                    if (progress < 1) requestAnimationFrame(tick);
                }
                requestAnimationFrame(tick);
            }

            // ----- Scroll-reveal (also drives count-up + bar chart on first view) -----
            const revealEls = document.querySelectorAll('.reveal');
            const io = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (!entry.isIntersecting) return;
                    entry.target.classList.add('is-visible');
                    entry.target.querySelectorAll('[data-count-to]').forEach(animateCount);
                    io.unobserve(entry.target);
                });
            }, { threshold: 0.1 });
            revealEls.forEach(el => io.observe(el));

            // Overview is visible on load — animate its counts immediately.
            document.querySelectorAll('#section-overview [data-count-to]').forEach(animateCount);

            // ----- Bar chart grow-in -----
            document.querySelectorAll('.bar-fill').forEach(bar => {
                const max = Math.max(...[...document.querySelectorAll('.bar-fill')].map(b => Number(b.dataset.height)));
                const pct = max ? (Number(bar.dataset.height) / max) * 100 : 0;
                requestAnimationFrame(() => {
                    bar.style.height = pct + '%';
                });
            });

            // ----- Toast helper -----
            const toast = document.getElementById('adminToast');
            let toastTimer;
            function showToast(message) {
                toast.textContent = message;
                toast.classList.add('is-open');
                clearTimeout(toastTimer);
                toastTimer = setTimeout(() => toast.classList.remove('is-open'), 2800);
            }

            // ----- Add / Edit room modal -----
            const roomModal = document.getElementById('roomModal');
            const roomModalTitle = document.getElementById('roomModalTitle');
            const roomForm = document.getElementById('roomForm');
            const roomNameInput = document.getElementById('roomName');
            const roomTierInput = document.getElementById('roomTier');
            const roomPriceInput = document.getElementById('roomPrice');
            const roomStatusInput = document.getElementById('roomStatus');

            function openRoomModal(mode, data) {
                roomModalTitle.textContent = mode === 'edit' ? 'Edit room' : 'Add room';
                roomForm.dataset.mode = mode;
                roomForm.dataset.id = data?.id || '';
                roomNameInput.value = data?.name || '';
                roomTierInput.value = data?.tier || 'comfort';
                roomPriceInput.value = data?.price ? data.price.replace(/,/g, '') : '';
                roomStatusInput.value = data?.status || 'available';
                roomModal.classList.add('is-open');
                roomModal.setAttribute('aria-hidden', 'false');
                document.body.classList.add('no-scroll');
            }

            function closeRoomModal() {
                roomModal.classList.remove('is-open');
                roomModal.setAttribute('aria-hidden', 'true');
                document.body.classList.remove('no-scroll');
            }

            document.getElementById('addRoomBtn')?.addEventListener('click', () => openRoomModal('add'));
            document.querySelectorAll('.edit-room-btn').forEach(btn => {
                btn.addEventListener('click', () => openRoomModal('edit', btn.dataset));
            });
            document.getElementById('roomModalClose')?.addEventListener('click', closeRoomModal);
            document.getElementById('roomModalBackdrop')?.addEventListener('click', closeRoomModal);

            roomForm?.addEventListener('submit', (e) => {
                e.preventDefault();
                // NOTE: demo only — wire this to a real POST/PUT to your RoomController.
                const isEdit = roomForm.dataset.mode === 'edit';
                closeRoomModal();
                showToast(isEdit ? 'Room updated.' : 'Room added.');
            });

            // ----- Delete room modal -----
            const deleteModal = document.getElementById('deleteModal');
            const deleteModalCopy = document.getElementById('deleteModalCopy');
            let pendingDeleteId = null;

            function openDeleteModal(id, name) {
                pendingDeleteId = id;
                deleteModalCopy.textContent = `"${name}" will be removed from the booking site. This can't be undone.`;
                deleteModal.classList.add('is-open');
                deleteModal.setAttribute('aria-hidden', 'false');
                document.body.classList.add('no-scroll');
            }

            function closeDeleteModal() {
                deleteModal.classList.remove('is-open');
                deleteModal.setAttribute('aria-hidden', 'true');
                document.body.classList.remove('no-scroll');
            }

            document.querySelectorAll('.delete-room-btn').forEach(btn => {
                btn.addEventListener('click', () => openDeleteModal(btn.dataset.id, btn.dataset.name));
            });
            document.getElementById('deleteModalCancel')?.addEventListener('click', closeDeleteModal);
            document.getElementById('deleteModalBackdrop')?.addEventListener('click', closeDeleteModal);
            document.getElementById('deleteModalConfirm')?.addEventListener('click', () => {
                // NOTE: demo only — wire this to a real DELETE request to your RoomController.
                const row = document.querySelector(`tr[data-room-id="${pendingDeleteId}"]`);
                row?.classList.add('is-removing');
                setTimeout(() => row?.remove(), 300);
                closeDeleteModal();
                showToast('Room deleted.');
            });

            // ----- Reservation status updates -----
            document.querySelectorAll('.status-select').forEach(select => {
                select.addEventListener('change', () => {
                    const row = select.closest('tr');
                    const pill = row.querySelector('.status-pill');
                    const labels = {
                        pending: 'Pending', confirmed: 'Confirmed',
                        checked_in: 'Checked in', checked_out: 'Checked out', cancelled: 'Cancelled',
                    };
                    pill.className = 'status-pill status-pill--' + select.value;
                    pill.textContent = labels[select.value];
                    row.dataset.status = select.value;
                    // NOTE: demo only — wire this to a real PATCH request to your ReservationController.
                    showToast('Reservation status updated.');
                });
            });

            // ----- Reservation filter -----
            const resFilter = document.getElementById('reservationFilter');
            const resBody = document.getElementById('reservationsTableBody');
            if (resFilter && resBody) {
                const pills = resFilter.querySelectorAll('.filter-pill');
                pills.forEach(pill => {
                    pill.addEventListener('click', () => {
                        pills.forEach(p => p.classList.toggle('is-active', p === pill));
                        const filter = pill.dataset.filter;
                        resBody.querySelectorAll('tr').forEach(row => {
                            const match = filter === 'all' || row.dataset.status === filter;
                            row.classList.toggle('is-row-hidden', !match);
                        });
                    });
                });
            }

            // ----- Export report (demo) -----
            document.getElementById('exportReportBtn')?.addEventListener('click', () => {
                // NOTE: demo only — wire this to a real export endpoint.
                showToast('Report export started.');
            });
        })();
    </script>
</body>
</html>
