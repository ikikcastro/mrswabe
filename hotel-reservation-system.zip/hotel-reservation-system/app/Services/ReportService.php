<?php

namespace App\Services;

use App\Models\Reservation;

/**
 * Aggregates reservation/room data into the numbers the owner dashboard
 * shows (occupancy, revenue, bookings per day, etc). Keeping this out of
 * the controller means the same figures can be reused by an export/CSV
 * endpoint later without duplicating the queries.
 */
class ReportService
{
    public function monthlyBookingsCount(): int
    {
        return Reservation::whereMonth('created_at', now()->month)->count();
    }

    public function bookingsPerDayThisWeek(): array
    {
        // Return an array of 7 counts, Monday..Sunday.
        return Reservation::query()
            ->whereBetween('check_in', [now()->startOfWeek(), now()->endOfWeek()])
            ->get()
            ->groupBy(fn ($r) => $r->check_in->dayOfWeekIso)
            ->map->count()
            ->all();
    }
}
