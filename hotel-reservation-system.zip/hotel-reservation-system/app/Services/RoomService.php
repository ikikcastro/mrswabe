<?php

namespace App\Services;

use App\Models\Room;

/**
 * Handles room CRUD and any business rules around room data
 * (e.g. preventing status changes that would orphan active reservations).
 */
class RoomService
{
    public function list()
    {
        return Room::all();
    }

    public function create(array $data): Room
    {
        return Room::create($data);
    }

    public function update(Room $room, array $data): Room
    {
        $room->update($data);
        return $room;
    }

    public function delete(Room $room): void
    {
        $room->delete();
    }
}
