<?php

namespace App\Services;

use App\Models\Reservation;
use App\Models\Room;

/**
 * Owns the double-booking rule: no two active reservations for the
 * same room may have overlapping check-in/check-out dates. Controllers
 * should always create/update reservations through this service rather
 * than calling Reservation::create() directly, so this check can't be
 * bypassed by a new code path later.
 */
class ReservationService
{
    public function hasConflict(Room $room, string $checkIn, string $checkOut, ?int $excludingReservationId = null): bool
    {
        return Reservation::where('room_id', $room->id)
            ->whereNotIn('status', ['cancelled'])
            ->when($excludingReservationId, fn ($q) => $q->where('id', '!=', $excludingReservationId))
            ->where('check_in', '<', $checkOut)
            ->where('check_out', '>', $checkIn)
            ->exists();
    }

    public function create(array $data): Reservation
    {
        $room = Room::findOrFail($data['room_id']);

        if ($this->hasConflict($room, $data['check_in'], $data['check_out'])) {
            throw new \DomainException('This room is already booked for the selected dates.');
        }

        return Reservation::create($data);
    }

    public function updateStatus(Reservation $reservation, string $status): Reservation
    {
        $reservation->update(['status' => $status]);
        return $reservation;
    }
}
