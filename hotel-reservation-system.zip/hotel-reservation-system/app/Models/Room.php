<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * A bookable room: name, tier (signature|comfort|essential),
 * price per night, status (available|maintenance), photos, amenities.
 */
class Room extends Model
{
    protected $fillable = ['name', 'tier', 'price', 'status', 'image', 'blurb'];

    public function reservations()
    {
        return $this->hasMany(Reservation::class);
    }
}
