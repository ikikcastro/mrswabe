<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * A single booking request: guest details, stay dates, status
 * (pending|confirmed|checked_in|checked_out|cancelled), linked room.
 */
class Reservation extends Model
{
    protected $fillable = [
        'room_id', 'user_id', 'full_name', 'contact_number',
        'check_in', 'check_out', 'status',
    ];

    protected $casts = [
        'check_in' => 'date',
        'check_out' => 'date',
    ];

    public function room()
    {
        return $this->belongsTo(Room::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
