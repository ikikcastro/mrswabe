<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

/** Blocks any non-owner from reaching /admin/* routes. */
class EnsureUserIsOwner
{
    public function handle(Request $request, Closure $next)
    {
        if (! $request->user() || $request->user()->role !== 'owner') {
            abort(403);
        }

        return $next($request);
    }
}
