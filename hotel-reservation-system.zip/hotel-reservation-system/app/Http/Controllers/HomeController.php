<?php

namespace App\Http\Controllers;

/** Renders welcome.blade.php — the logged-out/logged-in landing page. */
class HomeController extends Controller
{
    public function index()
    {
        return view('welcome');
    }
}
