<?php

namespace App\Http\Controllers;

use App\Services\RoomService;

/** Customer-facing room browsing — slideshow + grid on rooms.blade.php. */
class RoomController extends Controller
{
    public function __construct(private RoomService $rooms) {}

    public function index()
    {
        return view('rooms.index', ['rooms' => $this->rooms->list()]);
    }
}
