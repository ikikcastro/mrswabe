<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreBookingRequest;
use App\Services\ReservationService;

/** Handles the "Book this room" form submission. */
class BookingController extends Controller
{
    public function __construct(private ReservationService $reservations) {}

    public function store(StoreBookingRequest $request)
    {
        try {
            $this->reservations->create($request->validated());
        } catch (\DomainException $e) {
            return back()->withErrors(['check_in' => $e->getMessage()]);
        }

        return back()->with('status', 'Booking request sent.');
    }
}
