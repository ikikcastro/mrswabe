<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\UpdateReservationStatusRequest;
use App\Models\Reservation;
use App\Services\ReservationService;

/** Owner's reservation list + status updates (Pending -> Confirmed -> ...). */
class ReservationController extends Controller
{
    public function __construct(private ReservationService $reservations) {}

    public function index()
    {
        return view('admin.dashboard', ['reservations' => Reservation::with('room')->get()]);
    }

    public function updateStatus(UpdateReservationStatusRequest $request, Reservation $reservation)
    {
        $this->reservations->updateStatus($reservation, $request->validated()['status']);
        return back()->with('status', 'Reservation status updated.');
    }
}
