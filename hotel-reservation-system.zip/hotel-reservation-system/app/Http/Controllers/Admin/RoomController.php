<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreRoomRequest;
use App\Models\Room;
use App\Services\RoomService;

/** Owner's Add/Edit/Delete room actions (the modal in admin-dashboard.blade.php). */
class RoomController extends Controller
{
    public function __construct(private RoomService $rooms) {}

    public function store(StoreRoomRequest $request)
    {
        $this->rooms->create($request->validated());
        return back()->with('status', 'Room added.');
    }

    public function update(StoreRoomRequest $request, Room $room)
    {
        $this->rooms->update($room, $request->validated());
        return back()->with('status', 'Room updated.');
    }

    public function destroy(Room $room)
    {
        $this->rooms->delete($room);
        return back()->with('status', 'Room deleted.');
    }
}
