<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\ReportService;

/** Owner dashboard — overview stats, alerts. See admin-dashboard.blade.php. */
class DashboardController extends Controller
{
    public function __construct(private ReportService $reports) {}

    public function index()
    {
        return view('admin.dashboard', [
            'weekBookings' => $this->reports->bookingsPerDayThisWeek(),
        ]);
    }
}
