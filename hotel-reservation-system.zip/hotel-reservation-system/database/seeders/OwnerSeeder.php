<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

/** Seeds the one owner account (username: mark). Run once, then rotate the password. */
class OwnerSeeder extends Seeder
{
    public function run(): void
    {
        User::updateOrCreate(
            ['username' => 'mark'],
            [
                'name' => 'Mark',
                'email' => 'mark@ikikhouse.test',
                'password' => Hash::make('change-me-before-launch'),
                'role' => 'owner',
            ]
        );
    }
}
