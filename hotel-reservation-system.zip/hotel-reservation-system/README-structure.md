# Hotel Reservation System — Folder Structure

    app/
    ├── Http/
    │   ├── Controllers/
    │   │   ├── HomeController.php          welcome.blade.php
    │   │   ├── RoomController.php          rooms/index.blade.php (customer view)
    │   │   ├── BookingController.php       handles "Book this room" submissions
    │   │   ├── Auth/
    │   │   │   └── AdminLoginController.php   owner login (username: mark)
    │   │   └── Admin/
    │   │       ├── DashboardController.php    admin/dashboard.blade.php
    │   │       ├── RoomController.php         owner's add/edit/delete room
    │   │       └── ReservationController.php  owner's status updates
    │   ├── Requests/                      validation only, no business logic
    │   │   ├── Auth/  (RegisterRequest, LoginRequest)
    │   │   ├── Admin/ (StoreRoomRequest, UpdateReservationStatusRequest)
    │   │   └── StoreBookingRequest.php
    │   └── Middleware/
    │       └── EnsureUserIsOwner.php      blocks non-owners from /admin/*
    ├── Models/
    │   ├── User.php     (add via migration: username, role columns)
    │   ├── Room.php
    │   └── Reservation.php
    └── Services/                          business logic lives here, not in controllers
        ├── RoomService.php
        ├── ReservationService.php         <- double-booking guard lives here
        └── ReportService.php              dashboard stats + reports

    resources/
    ├── views/
    │   ├── welcome.blade.php              logged-in / logged-out landing page
    │   ├── layouts/                       (empty — shared <head>/nav if you split one out later)
    │   ├── rooms/
    │   │   ├── index.blade.php            slideshow + grid + booking modal
    │   │   └── partials/                  (empty — split lightbox/explore-modal out if index.blade.php grows)
    │   └── admin/
    │       ├── login.blade.php            owner-only sign-in
    │       └── dashboard.blade.php        overview / rooms / reservations / reports
    └── css/
        └── app.css

    database/
    ├── migrations/                        (empty — add rooms, reservations, and the
    │                                        users.username/role columns here)
    └── seeders/
        └── OwnerSeeder.php                creates the mark/owner account (hashed password)

    routes/
    └── web.php

## Why a Services layer?

Controllers stay thin — they validate (via Requests) and hand off to a
Service, which owns the actual business rules. The main reason this
matters here: `ReservationService::hasConflict()` is the single place
double-booking is checked. Every path that creates or edits a
reservation — the customer booking form, a future admin "create
reservation" feature — goes through this same service, so the rule
can't accidentally be skipped by a new controller later.

## What's still a stub

Every file here is a real, working skeleton (correct namespaces,
constructor-injected services, validation rules) but not wired to your
actual database yet. Before this runs:

1. Add `username` and `role` columns to `users` (see the migration
   snippet from earlier in this chat) and a `rooms` + `reservations`
   migration matching the fields used in `Room.php` / `Reservation.php`.
2. Run `php artisan db:seed --class=OwnerSeeder` and change the
   password immediately after.
3. Wire the JS `fetch`/form submissions in `rooms/index.blade.php` and
   `admin/dashboard.blade.php` (currently demo-only) to the routes in
   `routes/web.php`.
