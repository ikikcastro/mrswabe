<?php

use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\ReservationController as AdminReservationController;
use App\Http\Controllers\Admin\RoomController as AdminRoomController;
use App\Http\Controllers\Auth\AdminLoginController;
use App\Http\Controllers\BookingController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\RoomController;
use Illuminate\Support\Facades\Route;

// ----- Public / customer -----
Route::get('/', [HomeController::class, 'index']);
Route::get('/rooms', [RoomController::class, 'index']);
Route::post('/rooms/book', [BookingController::class, 'store']);

// ----- Owner auth -----
Route::get('/admin/login', [AdminLoginController::class, 'create']);
Route::post('/admin/login', [AdminLoginController::class, 'store']);

// ----- Owner dashboard (protected) -----
Route::middleware(['auth', 'owner'])->prefix('admin')->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index']);
    Route::post('/rooms', [AdminRoomController::class, 'store']);
    Route::put('/rooms/{room}', [AdminRoomController::class, 'update']);
    Route::delete('/rooms/{room}', [AdminRoomController::class, 'destroy']);
    Route::get('/reservations', [AdminReservationController::class, 'index']);
    Route::patch('/reservations/{reservation}/status', [AdminReservationController::class, 'updateStatus']);
});
